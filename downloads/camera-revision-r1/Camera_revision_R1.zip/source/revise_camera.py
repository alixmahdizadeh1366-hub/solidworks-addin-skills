"""Reference-based revision. Run with FreeCAD's Python, not SOLIDWORKS Python.
All dimensions mm. Only the explicitly annotated outer envelopes are constrained;
optics, wall thicknesses, radii and mechanical interfaces are estimates.
Original STEP is never overwritten.
"""
import sys,json,math
from pathlib import Path
sys.path.append('/usr/lib/freecad/lib')
import FreeCAD as App, Part, Import
ROOT=Path(__file__).resolve().parent
SOURCE=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('original.stp').resolve()
OUT=ROOT/'generated';OUT.mkdir(exist_ok=True)
P={'overall_length':280.0,'head_length':170.0,'head_width':95.0,'head_height':95.0,'box_width':110.0,'box_height':110.0,'box_depth':70.0,'box_wall':3.0,'box_corner_radius':18.0,'cover_depth':12.0,'seam_width':1.5,'optical_face_size':82.0,'optical_face_corner':18.0,'lens_outer_radius':19.0,'lens_clear_radius':13.5,'lamp_radius':4.5}
# Load original document cached during inspection, or import an unchanged source.
if (ROOT/'original_import.FCStd').exists(): src=App.openDocument(str(ROOT/'original_import.FCStd'))
else:
 src=App.newDocument('Original');Import.insert(str(SOURCE),src.Name)
by={o.Label:o for o in src.Objects if o.TypeId=='Part::Feature' and hasattr(o,'Shape') and len(o.Shape.Solids)==1}
doc=App.newDocument('Camera_Reference_Revision')
assembly=doc.addObject('App::Part','Camera');assembly.Label='Camera - reference-based revision R1'
parameters=doc.addObject('Spreadsheet::Sheet','Dimensions');parameters.Label='Dimensions (mm) - see comparison report'
for row,(k,v) in enumerate(P.items(),1):
 parameters.set('A'+str(row),k);parameters.set('B'+str(row),str(v));parameters.setAlias('B'+str(row),k)
# Cached mesh extrema are used only for normalization of the existing freeform shell.
# Their submillimetre tessellation uncertainty is stated in the report.
# Upgrade extrema to analytic OpenCascade optimal bounds when available.
bs=[by[n].Shape.optimalBoundingBox(False) for n in ('PRT0001','PRT0002','PRT0003')]
mi=[min(getattr(b,k) for b in bs) for k in ('XMin','YMin','ZMin')]
ma=[max(getattr(b,k) for b in bs) for k in ('XMax','YMax','ZMax')]
sH=P['head_height']/(ma[0]-mi[0]);sW=P['head_width']/(ma[1]-mi[1]);sL=P['head_length']/(ma[2]-mi[2]);start=mi[2];back=ma[2]
print('Analytic original head bounds:',mi,ma,'scale',sH,sW,sL,flush=True)
objects=[];preview=[];stats=[]
def add(name,shape,color,note):
 if not shape.isValid() or not shape.Solids:raise RuntimeError('Invalid/empty: '+name)
 o=doc.addObject('Part::Feature',name);o.Label=name.replace('_',' ');o.Shape=shape
 o.addProperty('App::PropertyString','Basis','Reference');o.Basis=note
 o.addProperty('App::PropertyColor','DisplayColor','Reference');o.DisplayColor=tuple(c/255 for c in color)
 assembly.addObject(o);objects.append(o)
 shape.exportBrep(str(OUT/(name+'.brep')))
 b=shape.optimalBoundingBox(False)
 stats.append(dict(name=o.Label,solids=len(shape.Solids),valid=True,volume_mm3=shape.Volume,bounds_mm=[b.XMin,b.XMax,b.YMin,b.YMax,b.ZMin,b.ZMax],basis=note))
 v,f=shape.tessellate(.6)
 # render.py swaps X/Z for the original model, so compensate here.
 preview.append(dict(name=name,color=color,vertices=[[p.z,p.y,p.x] for p in v],triangles=f))
 print('Added',name,flush=True);return o
white=(220,224,229);black=(22,27,33);cyan=(0,195,215);metal=(91,99,108)
def trans(shape,axialScale,offset):
 m=App.Matrix();m.A11=0;m.A12=0;m.A13=axialScale;m.A14=offset
 m.A21=0;m.A22=-sW;m.A23=0;m.A24=0
 m.A31=sH;m.A32=0;m.A33=0;m.A34=0
 return shape.transformGeometry(m)
for name,label,col in [('PRT0001','Camera_housing',white),('PRT0002','Front_bezel',black),('PRT0003','Sunshade',white),('PRT0008','Accent_left',cyan),('PRT0009','Accent_right',cyan),('PRT0013','Underside_panel',white),('PRT0014','Underside_insert',white)]:
 sh=trans(by[name].Shape,sL,-start*sL)
 add(label,sh,col,'Retained original shape; affine adjustment to 170 mm head length and 95 x 95 mm head envelope. Internal dimensions are changed by scaling.')
# Preserve bracket components together; shift instead of axially rescaling.
for n,label in [('PRT0004','Articulating_neck_front'),('PRT0006','Articulating_neck_rear')]:
 add(label,trans(by[n].Shape,1.0,P['head_length']-back),white,'Original neck geometry retained axially, transverse scale follows head. Joint load/clearance not verified.')
axis=App.Vector(1,0,0)
def cyl(r,x,length,y=0,z=0):return Part.makeCylinder(r,length,App.Vector(x,y,z),axis)
def rr(x,length,w,h,r,z=0):
 s=Part.makeBox(length,w,h,App.Vector(x,-w/2,z-h/2))
 edges=[e for e in s.Edges if e.BoundBox.XLength>length-.001 and e.BoundBox.YLength<.001 and e.BoundBox.ZLength<.001]
 return s.makeFillet(r,edges)
faceX=(-82.89034886344-start)*sL-0.4
add('Cyan_front_outline',rr(faceX,1.2,84,84,19).cut(rr(faceX-.1,1.4,82,82,18)),cyan,'Estimated 1 mm outline, fitted within retained bezel.')
add('Black_optical_face',rr(faceX+.05,2.0,82,82,18),black,'New front face masks original rectangular windows; estimated position and radii.')
lz=8.0
add('Lens_outer_bezel',cyl(19,faceX-2.0,2.5,0,lz).cut(cyl(15,faceX-2.1,2.7,0,lz)),(36,41,47),'Estimated circular lens bezel based on reference appearance.')
add('Lens_inner_ring',cyl(15,faceX-1.8,2.3,0,lz).cut(cyl(13.5,faceX-1.9,2.5,0,lz)),(64,70,80),'Estimated circular lens ring.')
add('Lens_glass_proxy',cyl(13.5,faceX-1.65,1.8,0,lz),(25,30,52),'Solid optical appearance proxy; not an optical lens prescription.')
add('Lens_aperture_proxy',cyl(7,faceX-1.7,.12,0,lz),(8,12,20),'Appearance proxy only.')
# Seven lamp positions inferred from the front view: two on each side, three below.
for i,(y,z) in enumerate([(-28,14),(-28,-8),(28,14),(28,-8),(-15,-28),(0,-30),(15,-28)],1):
 add('Lamp_%02d_rim'%i,cyl(5.5,faceX-.8,1.2,y,z).cut(cyl(4.5,faceX-.9,1.4,y,z)),(125,128,123),'Estimated emitter placement/diameter; electrical/optical function unspecified.')
 add('Lamp_%02d_face'%i,cyl(4.5,faceX-.75,.9,y,z),(234,220,174),'Solid appearance proxy for visible/IR emitter.')
# Box extends from 210 to 280. Shells and gasket are distinct solids.
bx=P['overall_length']-P['box_depth'];split=bx+P['cover_depth'];seam=P['seam_width'];r=P['box_corner_radius'];wall=P['box_wall']
outer=rr(split+seam,280-(split+seam),110,110,r)
inner=rr(split+seam-.1,280-wall-(split+seam)+.1,110-2*wall,110-2*wall,r-wall)
base=outer.cut(inner)
# Mounting holes, deliberately retained as estimates rather than claimed fastener standards.
for y in (-39,39):
 for z in (-39,39):base=base.cut(cyl(2.5,276.5,4.5,y,z))
base=base.cut(cyl(11,276.5,4.5))
add('Junction_box_rear_shell',base,white,'110 x 110 mm envelope, rear X=280. 3 mm walls, corner radii, cable bore and mounting holes are estimates.')
cover=rr(bx,P['cover_depth'],110,110,r).cut(rr(bx+wall,P['cover_depth']-wall+.1,104,104,r-wall))
# Neck enters through the circular cover opening.
cover=cover.cut(cyl(18,bx-.1,wall+.2))
add('Junction_box_front_cover',cover,white,'Front X=210; estimated hollow front cover with central cable/neck opening.')
gasket=rr(split,seam,109,109,r-.5).cut(rr(split-.1,seam+.2,103,103,r-3.5))
add('Junction_box_cyan_seam',gasket,cyan,'Estimated accent/seal geometry; no ingress protection claim.')
# Collar masks the junction between the retained neck and the new box cover.
add('Junction_box_neck_collar',cyl(25,bx-3,3).cut(cyl(18,bx-3.1,3.2)),white,'Estimated collar around retained neck; not a verified bearing or seal.')
doc.recompute();doc.saveAs(str(OUT/'Camera_reference_revision.FCStd'))
Import.export([assembly],str(OUT/'Camera_reference_revision.step'))
json.dump(dict(parameters=P,original_head_bounds_mm=[mi,ma],parts=stats),open(OUT/'validation.json','w'),indent=2)
json.dump(preview,open(ROOT/'revised_mesh.json','w'))
print('SAVED',len(objects),'components',flush=True)
