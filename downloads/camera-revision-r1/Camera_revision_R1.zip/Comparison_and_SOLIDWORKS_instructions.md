# Camera reference revision R1

This is a reference-based CAD revision of the supplied `11-6_asm (1).stp`, not an exact or manufacturing-approved reconstruction. The original upload is unchanged. The supplied STEP header identifies Creo Parametric as its authoring system and millimetres as its length unit.

## Files and use

- `Camera_reference_revision.step`: colored solid assembly for import into SOLIDWORKS. This is the main deliverable.
- `Camera_reference_revision.FCStd`: FreeCAD document with named solid components, source/assumption notes and a dimension-record spreadsheet. The spreadsheet records the construction values; changing it does not regenerate the geometry.
- `Revised_model_views.png`: views rendered from the revised CAD geometry, not an AI concept image. Tessellation/render shading may show artifacts not present in the B-rep solids.
- `Original_model_views.png`: views of the unmodified supplied model.
- `validation.json`: component-level geometry validity, bounds, volumes and assumptions before export.
- `export_verification.json`: independent STEP reimport check.
- `source/`: construction/export scripts for further controlled revisions. These require FreeCAD Python and CadQuery 2.7/OpenCascade; they are not SOLIDWORKS macros.

In SOLIDWORKS, open the STEP using File > Open, with solid/assembly import enabled. Import options vary by version; retain separate components/bodies. Run Import Diagnostics and inspect the units (mm). If 3D Interconnect leaves a linked imported feature, use your version's supported break/dissolve-link workflow before direct editing. Save the imported model as your own native SOLIDWORKS assembly/parts. Move Face, Delete Face and new sketches/features can edit imported solids. Native original feature history, mates and a SOLIDWORKS feature tree are not provided. This file has not been opened in SOLIDWORKS in this environment.

## Whole-model comparison

Original values below use OpenCascade analytic optimal bounds, not loose NURBS control-pole bounding boxes. They describe geometry rather than pixel measurements.

| Area | Supplied model | Reference | R1 action / remaining difference |
|---|---|---|---|
| Overall length | 254.456 mm including hood | 280 mm standard size | Revised envelope is 280 mm |
| Head including hood | 189.056 mm axial length | 170 mm camera-body annotation | Interpreted as head including hood; adjusted to 170 mm |
| Front bezel | 79.01 mm high x 79.00 mm wide | 95 x 95 mm front-view annotation | Full head/hood envelope adjusted to 95 x 95 mm; retained inset bezel remains smaller |
| Full head envelope | 87.169 mm high x 87.975 mm wide | 95 x 95 mm | Independent axis scaling to those envelope targets; this changes original walls, holes and interfaces |
| Junction base | Shallow 84 x 84 x 25.4 mm mounting plate | 110 x 110 x 70 mm box | Replaced by hollow rounded box, cover, cyan seam and neck collar |
| Neck and rear section | Exposed articulated bracket and thin wall plate | Neck integrated with deeper box | Bracket geometry retained and repositioned; front interfaces scaled with the head |
| Front optical arrangement | Rectangular windows, no matching circular lens/7-light face | Round central lens with surrounding lamps | New black face, circular lens proxies and seven surrounding lamp positions; dimensions/positions are estimates |
| Sunshade | Similar swept hood with overhanging angled front edge | Similar design, different proportions | Existing freeform surfaces retained and scaled; exact curvature, thickness and edge treatment not recoverable from the image |
| Side cyan accents | Existing solid strip geometry | Thin cyan trim following upper side seam | Retained and scaled; exact strip endpoints and section still differ |
| Bottom microphone/speaker | Rectangular service-panel/insert geometry | Two circular perforated grilles | Retained original panel; circular grille layout remains to be remodeled from measurements |
| Side D markings | Not reproduced | Visible D emblems | Not added; exact artwork, location and depth unavailable |
| Surface finish and styling | Original modeled seams, cutouts and details | White finish with distinct rounded/swept transitions | Approximate CAD colors applied; retained details are not a pixel-exact match |
| Internal electronics | Original optical/plate components | Illustrated PCB, RJ45, power, alarm, audio and service connectors | Incompatible original optics removed for new front layout; connector/PCB internals not reconstructed |
| Cable entry / seals | Existing mounting architecture | Weather-sealed cable route through junction base | Estimated center bore and hollow box supplied; glands, gaskets, sealing interfaces and connector clearance not engineered |
| Mounting alternatives | One assembly | Wall/ceiling/pole/junction-box concepts | Standard wall configuration only; other pictured options are separate designs |
| Compact/long-range options | One size | 220 / 280 / 340 mm alternatives | Standard 280 mm version only |

## What is dimensionally controlled

The revision uses +X from the camera toward the wall, +Z up, millimetres throughout. The head occupies X=0..170 mm. The box occupies X=210..280 mm, Y=-55..55 mm, Z=-55..55 mm. Thus the 110 mm rear axial allocation in the reference is interpreted as 40 mm exposed neck + 70 mm junction-box depth. The reference also shows 95 mm for the head and 110 mm for the larger base; these are separate envelopes.

The 95 mm front annotation is interpreted as the envelope including the sunshade rather than a 95 mm glass face. That interpretation must be confirmed before manufacturing. Some pictured views are stylized/inconsistent, so tracing every view simultaneously cannot yield one uniquely defined solid.

## Estimated details and limits

Box corner radius 18 mm, nominal wall 3 mm, cover depth 12 mm and seam width 1.5 mm are design assumptions. Cable bore and mounting-hole diameters/locations are estimates. The 82 mm black face, 19 mm outer lens radius, 13.5 mm clear-lens radius, lamp diameters and all optical positions are visual estimates. Optical solids only represent appearance, not optical prescriptions or certified components. No emissive lighting, electronics operation, 4K performance, IP66/IK10 rating, structural load capacity, watertightness or manufacturability is established.

The original head and neck contain mating/overlapping bodies; the revision retains that architecture. Cross-component interference, articulation range, wall/fastener adequacy, assembly access and seal compression have not been validated. Head scaling affects original fit dimensions. Further CAD work and physical measurements are required before tooling or manufacture.

## Validation

The final colored STEP is reimported independently with CadQuery/OpenCascade. `export_verification.json` records the executed result: component count, B-rep validity, positive solid volumes and 280 x 110 x 110 mm overall envelope. This is a geometry/export check, not a SOLIDWORKS interoperability or mechanical-fit certification. `validation.json` also records each component's exact calculated bounds and construction basis.

## Rebuilding

On a Linux setup with FreeCAD's Python modules and CadQuery installed, run `python3 source/revise_camera.py '/path/to/original.stp'` using the Python interpreter compatible with FreeCAD. Then run `python source/export_colored.py` using the CadQuery interpreter. The output directory is `source/generated`. The scripts regenerate this specific revision; they do not recover the original parametric history, and the fixed construction values must be edited consistently for a different design.
