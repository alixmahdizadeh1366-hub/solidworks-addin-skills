import json,math
from pathlib import Path
import cadquery as cq
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Cylinder
ROOT=Path(__file__).resolve().parent;out=ROOT/'deliverables'
s=cq.importers.importStep(str(out/'Camera_reference_revision_R2.step')).val()
sol=s.Solids();assert len(sol)==sum(p['solid_count'] for p in json.load(open(out/'validation_R2.json'))['parts']),len(sol);assert all(p.isValid() and p.Volume()>0 for p in sol)
b=Bnd_Box();BRepBndLib.AddOptimal_s(s.wrapped,b,False,False);box=b.Get();size=[box[k+3]-box[k] for k in range(3)]
for got,want in zip(size,[280,110,110]):assert abs(got-want)<.001,(got,want)
centers=[]
for f in s.Faces():
 a=BRepAdaptor_Surface(f.wrapped)
 if a.GetType()==GeomAbs_Cylinder:
  c=a.Cylinder();ax=c.Axis().Direction()
  if abs(c.Radius()-.65)<1e-6 and abs(abs(ax.Z())-1)<1e-6:
   p=c.Location();centers.append((p.X(),p.Y()))
assert len(centers)==122,len(centers)
for lo,hi,want in [(0,85,55),(85,170,115)]:
 pts=[c for c in centers if lo<c[0]<hi];assert len(pts)==61,len(pts)
 assert abs(sum(p[0] for p in pts)/61-want)<1e-5
 assert abs(sum(p[1] for p in pts)/61)<1e-5
core=cq.importers.importBrep(str(out/'Housing_core_R2.brep')).val()
checks={}
for name in ('Side_panel_left_R2','Side_panel_right_R2','Cyan_side_trim_left_R2','Cyan_side_trim_right_R2'):
 part=cq.importers.importBrep(str(out/(name+'.brep'))).val()
 v=core.intersect(part).Volume();checks[name]=v
 assert v<1e-4,(name,v)
record=dict(revision='R2',step_reimport_solid_count=len(sol),all_solids_valid=True,all_solids_positive_volume=True,overall_dimensions_mm=size,grille_hole_count=122,holes_per_grille=61,hole_diameter_mm=1.3,grille_centers_x_mm=[55,115],new_panel_and_trim_overlap_with_core_mm3=checks,native_solidworks_validation='Not performed; unavailable',reference_profile_accuracy='Visual reconstruction; unannotated dimensions are estimated')
json.dump(record,open(out/'export_verification_R2.json','w'),indent=2);print(json.dumps(record,indent=2))
