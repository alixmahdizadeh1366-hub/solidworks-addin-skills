"""R2: smooth housing, separate swept side panels, two physical underside grilles.
Run with a Python compatible with FreeCAD, optionally supplying R1 FCStd as argv[1].
All units mm. Unannotated profile and grille dimensions are visual estimates.
"""
import sys,json,math
from pathlib import Path
sys.path.append('/usr/lib/freecad/lib')
import FreeCAD as A,Part,Import
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
SOURCE=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'R1_input.FCStd'
src=A.openDocument(str(SOURCE))
D=A.newDocument('Camera_R2');group=D.addObject('App::Part','Camera');group.Label='Camera reference revision R2'
objects=[];stats=[];mesh=[]
white=(220,224,229);black=(22,27,33);cyan=(0,195,215)
def add(name,sh,color,note):
 assert sh.isValid() and len(sh.Solids)>0,(name,'invalid/empty')
 o=D.addObject('Part::Feature',name);o.Label=name.replace('_',' ');o.Shape=sh
 o.addProperty('App::PropertyString','Basis','Reference');o.Basis=note
 o.addProperty('App::PropertyColor','DisplayColor','Reference');o.DisplayColor=tuple(c/255 for c in color)
 group.addObject(o);objects.append(o);sh.exportBrep(str(OUT/(name+'.brep')))
 b=sh.optimalBoundingBox(False)
 stats.append(dict(name=name,solid_count=len(sh.Solids),valid=True,volume_mm3=sh.Volume,bounds_mm=[b.XMin,b.XMax,b.YMin,b.YMax,b.ZMin,b.ZMax],basis=note))
 v,f=sh.tessellate(.5)
 mesh.append(dict(name=name,color=color,vertices=[[p.z,p.y,p.x] for p in v],triangles=f))
 print('Added',name,len(sh.Solids),flush=True)
# Keep R1 optics, sunshade, articulated neck, and junction box.
exclude={'Camera_housing','Underside_panel','Underside_insert','Accent_left','Accent_right'}
for o in src.Objects:
 if o.TypeId=='Part::Feature' and o.Name not in exclude:
  color=tuple(round(c*255) for c in o.DisplayColor[:3])
  add(o.Name,o.Shape.copy(),color,'Retained R1 component. '+getattr(o,'Basis',''))
V=A.Vector
# Rounded YZ sections: corresponding lines/arcs produce smooth longitudinal surfaces.
def section(x,w,h,r,zc):
 sh=Part.makeBox(1,w,h,V(x,-w/2,zc-h/2))
 ed=[e for e in sh.Edges if e.BoundBox.XLength>.999 and e.BoundBox.YLength<1e-5 and e.BoundBox.ZLength<1e-5]
 sh=sh.makeFillet(r,ed)
 face=next(f for f in sh.Faces if f.BoundBox.XLength<1e-5 and abs(f.BoundBox.XMin-x)<1e-5)
 return face.OuterWire
# Constant rounded cross-section avoids unmeasured waves in an interpolated loft.
outer=Part.makeLoft([section(12.6,89,87.4,18,-1.2),section(170,89,87.4,18,-1.2)],True,True)
wall=2.5
inner=Part.makeLoft([section(12.5,84,82.4,15.5,-1.2),section(170.1,84,82.4,15.5,-1.2)],True,True)
# Swept diagonal rear boundary, read from the marked reference silhouette.
rear=Part.BezierCurve();rear.setPoles([V(170,-60,45),V(167,-60,18),V(153,-60,-23),V(145,-60,-47)])
edges=[Part.makeLine(V(10,-60,60),V(170,-60,60)),Part.makeLine(V(170,-60,60),V(170,-60,45)),rear.toShape(),Part.makeLine(V(145,-60,-47),V(10,-60,-60)),Part.makeLine(V(10,-60,-60),V(10,-60,60))]
rear_mask=Part.Face(Part.Wire(edges)).extrude(V(0,120,0))
inner_rear=rear_mask.copy();inner_rear.translate(V(-2.5,0,0))
shell=outer.common(rear_mask).cut(inner.common(inner_rear))
shell=shell.cut(Part.makeCylinder(14,45,V(130,0,0),V(1,0,0)))
assert shell.isValid() and len(shell.Solids)==1,'Housing is invalid'
print('Smooth hollow housing built',flush=True)
# The side-panel boundary is defined in XZ and extruded through both sides.
def bez(points):
 c=Part.BezierCurve();c.setPoles([V(x,-60,z) for x,z in points]);return c.toShape()
def panel_mask(zshift=0):
 def p(x,z):return (x,z+zshift)
 segments=[
 [p(26,5),p(55,5.7),p(96,6),p(122,6)],
 [p(122,6),p(135,6),p(141,22),p(151,37)],
 [p(151,37),p(155,40),p(161,40),p(166,36)],
 [p(166,36),p(171,14),p(157,-20),p(145,-35)],
 [p(145,-35),p(139,-41),p(130,-42),p(115,-43)],
 [p(115,-43),p(82,-45),p(41,-46),p(18,-45)],
 [p(18,-45),p(17,-35),p(23,-11),p(26,5)]]
 wire=Part.Wire([bez(s) for s in segments]);return Part.Face(wire).extrude(V(0,120,0))
print('Making panel mask',flush=True)
mask=panel_mask()
print('Panel mask built',flush=True)
# Side-shell sectors begin at |Y|=27; central underside remains continuous.
left=Part.makeBox(200,40,120,V(0,27,-60));right=Part.makeBox(200,40,120,V(0,-67,-60))
sectors=Part.Compound([left,right])
paneltools=mask.common(sectors)
print('Panel tools built',flush=True)
panels=shell.common(paneltools)
print('Panel intersection built',flush=True)
# A 0.65 mm upper relief makes the parting line physical. Translating the mask
# opens this line at the top and slightly adjusts the hidden lower boundary.
print('Making relief',flush=True)
relief=panel_mask(.65).common(sectors).fuse(paneltools)
print('Relief built',flush=True)
core=shell.cut(relief)
print('Core cut complete',flush=True)
assert core.isValid() and len(core.Solids)>0
strip_profile=Part.makePolygon([V(28,-60,5.05),V(124,-60,6.05),V(128,-60,7.8),V(126,-60,9.1),V(28,-60,7.0),V(28,-60,5.05)])
stripmask=Part.Face(strip_profile).extrude(V(0,120,0)).common(sectors)
# Derive trim from the outer shell, inset 0.15 mm in Y to avoid overlap with shade.
strip=shell.common(stripmask)
core=core.cut(stripmask)
assert core.isValid()
# Drill only the simple rebuilt housing, not the original densely trimmed B-splines.
# 61-hole concentric circular arrangement in each circular grille, diameter 22.9 mm.
centers=(55.,115.);pitch=2.4;radius=.65;holes=[]
for cx in centers:
 positions=[(cx,0)]
 for ring in range(1,5):
  for k in range(6*ring):
   angle=2*math.pi*k/(6*ring)
   positions.append((cx+ring*pitch*math.cos(angle),ring*pitch*math.sin(angle)))
 for x,y in positions:holes.append(Part.makeCylinder(radius,16,V(x,y,-50),V(0,0,1)))
# Use one grille per boolean to bound operation size.
for i in range(2):
 print('Drilling grille',i+1,flush=True)
 core=core.cut(Part.Compound(holes[i*61:(i+1)*61]))
 assert core.isValid() and len(core.Solids)>0
# Dark front recess makes the swept leading edge visible, as in the reference.
front_recess_mask=Part.makeBox(17.5,120,60,V(12.5,-60,-50))
front_recess=core.common(front_recess_mask)
core=core.cut(front_recess_mask)
add('Front_side_recess_R2',front_recess,black,'Dark front recess, split from the housing, exposes the curved leading edge of the white side panels. Visual reconstruction.')
add('Housing_core_R2',core,white,'Rebuilt rounded hollow housing with swept rear boundary. 2.5 mm estimated wall. Two actual 61-hole underside grilles: X=55/115, Y=0, diameter 1.3, radial ring pitch 2.4 mm. Locations and diameters visually inferred; not certified acoustic/sealing design.')
# Keep side panels separate for independent direct editing after STEP import.
for name,tool in [('Side_panel_left_R2',left),('Side_panel_right_R2',right)]:
 sh=panels.common(tool)
 add(name,sh,white,'Separate curved shell panel following the red-marked side reference. Swept front boundary, rising rear boundary, and tapered tail. Control points visually inferred. Upper relief nominally 0.65 mm.')
# Cyan strip occupies the long, narrow upper seam. It is trimmed to the housing
# surface, with its rear extent stopped before the steeply rising panel tail.
for name,tool in [('Cyan_side_trim_left_R2',left),('Cyan_side_trim_right_R2',right)]:
 s=strip.common(tool)
 if s.Solids:add(name,s,cyan,'Visual trim aligned with the upper side-panel seam; estimated profile. It shares housing surfaces and is not a functional light-guide design.')
for i,cx in enumerate(centers,1):
 add('Grille_backing_proxy_%d'%i,Part.makeCylinder(11.6,.3,V(cx,0,-38.5),V(0,0,1)),black,'Dark internal screen appearance proxy behind real grille holes. Material, acoustic behavior and water sealing are not specified or verified.')
D.recompute();D.saveAs(str(OUT/'Camera_reference_revision_R2.FCStd'))
Import.export([group],str(OUT/'Camera_reference_revision_R2_uncolored.step'))
json.dump(dict(revision='R2',parts=stats,grille_centers_x_mm=centers,hole_count_per_grille=61,hole_diameter_mm=1.3,radial_ring_pitch_mm=pitch,wall_nominal_mm=wall),open(OUT/'validation_R2.json','w'),indent=2)
json.dump(mesh,open(ROOT/'revised_mesh.json','w'))
print('R2 complete',len(objects),'components',sum(len(o.Shape.Solids) for o in objects),'solids',flush=True)
