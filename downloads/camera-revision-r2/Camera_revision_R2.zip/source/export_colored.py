import cadquery as cq,json
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'deliverables'
stats=json.load(open(out/'validation_R2.json'))
a=cq.Assembly(name='Camera_reference_revision_R2')
# Colors must be applied in the STEP assembly exporter; the headless FreeCAD
# document separately records display colors as metadata.
mesh=json.load(open(root/'revised_mesh.json'))
for p in mesh:
 shape=cq.importers.importBrep(str(out/(p['name']+'.brep'))).val()
 assert shape.isValid(),p['name']
 a.add(shape,name=p['name'],color=cq.Color(*[c/255 for c in p['color']]))
a.save(str(out/'Camera_reference_revision_R2.step'))
print('Exported colored STEP with',len(mesh),'solid components')
